Disco PWM ver. 0.1a
By Duke Nukem, May 2020

Skycontroller files

buttons is the user configuration file.

Please copy these files to the following locations on your Skycontroller 2:

/etc/boxinit.d/99-discopwm.rc  (CHMOD 640)
/data/lib/ftp/uavpal/conf/buttons
/data/lib/ftp/uavpal/bin/disco_pwm.sh (CHMOD u+x)


Once you have done the above, restart the skycontroller in order for your button mapping to be live. 
