Disco PWM ver. 0.2a
By Duke Nukem, May 2020

Disco files

Please copy these files to the following locations on your Disco:

/etc/boxinit.d/99-activateservos.rc  (CHMOD 640)
/data/ftp/uavpal/bin/activateservos.sh (CHMOD u+x)

Once you have done the above, restart the drone and all servo rails will be enabled with default settings.
